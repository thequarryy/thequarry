<!doctype html>
<html lang="tr">
	<meta HTTP-EQUIV="Refresh" CONTENT="0; URL=iamfutures.github.io/index.php">
	</html>